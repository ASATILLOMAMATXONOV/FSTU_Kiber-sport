const nodemailer = require("nodemailer");
require("dotenv").config();

const transporter = nodemailer.createTransport({
	service: "gmail",
	auth: {
		user: process.env.EMAIL_USER,
		pass: process.env.EMAIL_PASS,
	},
});

async function sendConfirmationEmail(email, name) {
	await transporter.sendMail({
		from: process.env.EMAIL_USER,
		to: email,
		subject: "✅ Ro‘yxat tasdiqlandi",
		text: `Assalomu alaykum!\n\nSiz FSTU KIBERSPORT uchun yuborgan so‘rovingiz qabul qilindi va tasdiqlandi.\n\nHurmat bilan,\nFSTU Kibersport jamoasi`,
	});
}

module.exports = sendConfirmationEmail;
