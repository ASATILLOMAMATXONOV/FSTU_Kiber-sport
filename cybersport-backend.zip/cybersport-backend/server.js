const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const pool = require("./db");
require("dotenv").config();
// Routerlar keyin chaqiriladi
const registerRoute = require("./routes/register");
const approveRoute = require("./routes/approve");
const app = express();

app.use(cors());
app.use(bodyParser.json()); // JSON requestlar uchun body parser



// Middlewares birinchi bo'lishi kerak

async function connectDB() {
	try {
		await pool.connect();
		console.log("✅ Ma'lumotlar bazasi bilan bog'landi");
		return pool;
	} catch (err) {
		console.error("❌ Ma'lumotlar bazasi bilan bog'lanishda xato:", err.message);
		process.exit(1);
	}
}
connectDB();



app.use("/register", registerRoute);
app.use("/approve", approveRoute);
// Serverni ishga tushirish
app.listen(process.env.PORT || 3001, () => {
	console.log(`✅ Server ishlayapti: http://localhost:${process.env.PORT || 3001} yoki Railway domenida`);
});

