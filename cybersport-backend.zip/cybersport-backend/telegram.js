const axios = require("axios");
require("dotenv").config();

async function notifyTelegram(data) {
	const message = `
🆕 *Yangi ro‘yxat!*
👤 Ism: ${data.name}
📧 Email: ${data.email}
📱 Tel: ${data.phone}
🎮 O‘yin: ${data.game}
👥 Jamoa: ${data.is_team ? "Ha" : "Yo‘q"}
`;

	try {
		await axios.post(`https://api.telegram.org/bot${process.env.TELEGRAM_TOKEN}/sendMessage`, {
			chat_id: process.env.TELEGRAM_CHAT_ID,
			text: message,
			parse_mode: "Markdown",
			reply_markup: {
				inline_keyboard: [
					[
						{
							text: "✅ Tasdiqlash",
							url: `${process.env.BASE_URL}/approve/${data.id}`
						}
					]
				]
			}
		});
		console.log("✅ Telegramga yuborildi.");
	} catch (error) {
		console.error("❌ Telegram xatosi:", error.message);
	}
}

module.exports = notifyTelegram;