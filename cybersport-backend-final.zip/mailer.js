const nodemailer = require("nodemailer");
require("dotenv").config();

const transporter = nodemailer.createTransport({
	service: "gmail",
	auth: {
		user: process.env.EMAIL_USER,
		pass: process.env.EMAIL_PASS,
	},
});

async function sendConfirmationEmail(email, name, status) {
	let subject = "";
	let text = "";

	if (status === "approved") {
		subject = "✅ Ro‘yxat tasdiqlandi";
		text = `Assalomu alaykum!\n\nSiz FSTU KIBERSPORT uchun yuborgan so‘rovingiz qabul qilindi va tasdiqlandi.\n\nHurmat bilan,\nFSTU Kibersport jamoasi`;
	} else if (status === "rejected") {
		subject = "❌ Ro‘yxat rad etildi";
		text = `Assalomu alaykum!\n\nSiz FSTU KIBERSPORT uchun yuborgan so‘rovingiz rad etildi.\n\nHurmat bilan,\nFSTU Kibersport jamoasi`;
	}

	await transporter.sendMail({
		from: process.env.EMAIL_USER,
		to: email,
		subject,
		text,
	});
}

module.exports = sendConfirmationEmail;